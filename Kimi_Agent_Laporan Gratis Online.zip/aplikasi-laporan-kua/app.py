"""
Aplikasi Laporan Bulanan KUA
Gratis dan Open Source - Dapat digunakan selamanya
"""

from flask import Flask, render_template, request, redirect, url_for, flash, send_file, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import pandas as pd
import os
from datetime import datetime, date
from dateutil.relativedelta import relativedelta
import json
from io import BytesIO
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, landscape, A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch, cm
from reportlab.pdfgen import canvas
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
import openpyxl
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill

app = Flask(__name__)
app.config['SECRET_KEY'] = 'kua-laporan-bulanan-secret-key-2024'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///kua_database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Buat folder upload jika belum ada
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# ==================== TEMPLATE FILTERS ====================

@app.template_filter('datetimeformat')
def datetimeformat(value, format='%d'):
    if value is None:
        return ''
    if isinstance(value, str):
        try:
            value = datetime.strptime(value, '%Y-%m-%d %H:%M:%S')
        except:
            return value
    return value.strftime(format)

@app.context_processor
def inject_now():
    return {'now': datetime.now}

# ==================== MODELS ====================

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)
    is_admin = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.now)

class DataKUA(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nama_kua = db.Column(db.String(200), nullable=False)
    nama_kepala_kua = db.Column(db.String(200), nullable=False)
    nip_kepala_kua = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(100))
    no_hp = db.Column(db.String(20))
    alamat = db.Column(db.Text)
    kode_pos = db.Column(db.String(10))
    provinsi = db.Column(db.String(100), default='LAMPUNG')
    kabupaten = db.Column(db.String(100), default='KAB. LAMPUNG TENGAH')
    kecamatan = db.Column(db.String(100), default='ANAK RATU AJI')
    kode_kua = db.Column(db.String(20), default='1802271')
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)

class Desa(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nama_desa = db.Column(db.String(100), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now)

class NoPorporasi(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    bulan = db.Column(db.Integer, nullable=False)
    tahun = db.Column(db.Integer, nullable=False)
    no_awal = db.Column(db.String(50), nullable=False)
    no_akhir = db.Column(db.String(50), nullable=False)
    jumlah = db.Column(db.Integer, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now)

class DataPernikahan(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    
    # Identitas Pernikahan
    no_urut = db.Column(db.Integer)
    no_seri_huruf = db.Column(db.String(20))
    no_perforasi = db.Column(db.String(50))
    no_pemeriksaan = db.Column(db.String(50))
    no_aktanikah = db.Column(db.String(50))
    no_pendaftaran = db.Column(db.String(50))
    tanggal_daftar = db.Column(db.Date)
    tanggal_akad = db.Column(db.Date)
    jam_akad = db.Column(db.String(10))
    alamat_akad = db.Column(db.Text)
    nama_kelurahan = db.Column(db.String(100))
    
    # Data Suami
    nik_suami = db.Column(db.String(20))
    nama_suami = db.Column(db.String(200))
    tempat_lahir_suami = db.Column(db.String(100))
    tanggal_lahir_suami = db.Column(db.Date)
    umur_suami = db.Column(db.Integer)
    warganegara_suami = db.Column(db.String(20))
    pendidikan_suami = db.Column(db.String(50))
    pekerjaan_suami = db.Column(db.String(100))
    alamat_suami = db.Column(db.Text)
    status_suami = db.Column(db.String(50))
    nama_ayah_suami = db.Column(db.String(200))
    nama_ibu_suami = db.Column(db.String(200))
    
    # Data Istri
    nik_istri = db.Column(db.String(20))
    nama_istri = db.Column(db.String(200))
    tempat_lahir_istri = db.Column(db.String(100))
    tanggal_lahir_istri = db.Column(db.Date)
    umur_istri = db.Column(db.Integer)
    warganegara_istri = db.Column(db.String(20))
    pendidikan_istri = db.Column(db.String(50))
    pekerjaan_istri = db.Column(db.String(100))
    alamat_istri = db.Column(db.Text)
    status_istri = db.Column(db.String(50))
    nama_ayah_istri = db.Column(db.String(200))
    nama_ibu_istri = db.Column(db.String(200))
    
    # Data Wali
    status_wali = db.Column(db.String(50))
    hubungan_wali = db.Column(db.String(100))
    sebab_wali = db.Column(db.String(200))
    nik_wali = db.Column(db.String(20))
    nama_wali = db.Column(db.String(200))
    tempat_lahir_wali = db.Column(db.String(100))
    tanggal_lahir_wali = db.Column(db.Date)
    alamat_wali = db.Column(db.Text)
    
    # Data Penghulu
    nip_penghulu = db.Column(db.String(50))
    nama_penghulu = db.Column(db.String(200))
    
    # Data Saksi
    nik_saksi1 = db.Column(db.String(20))
    nama_saksi1 = db.Column(db.String(200))
    nik_saksi2 = db.Column(db.String(20))
    nama_saksi2 = db.Column(db.String(200))
    
    # Data Pembayaran
    mas_kawin = db.Column(db.String(200))
    no_ntpn = db.Column(db.String(50))
    tanggal_bayar = db.Column(db.DateTime)
    
    # Kategori
    nikah_di = db.Column(db.String(50))  # LUAR KUA / BEDOL atau DI KUA
    isbat_nikah = db.Column(db.Boolean, default=False)
    rujuk = db.Column(db.Boolean, default=False)
    
    # Metadata
    bulan = db.Column(db.Integer)
    tahun = db.Column(db.Integer)
    created_at = db.Column(db.DateTime, default=datetime.now)

class StokBukuNikah(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    bulan = db.Column(db.Integer, nullable=False)
    tahun = db.Column(db.Integer, nullable=False)
    saldo_bulan_lalu = db.Column(db.Integer, default=0)
    penerimaan = db.Column(db.Integer, default=0)
    pengeluaran = db.Column(db.Integer, default=0)
    duplikat = db.Column(db.Integer, default=0)
    rusak_hilang = db.Column(db.Integer, default=0)
    saldo_bulan_ini = db.Column(db.Integer, default=0)
    no_awal = db.Column(db.String(50))
    no_akhir = db.Column(db.String(50))
    created_at = db.Column(db.DateTime, default=datetime.now)

# ==================== LOGIN MANAGER ====================

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# ==================== ROUTES ====================

@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.query.filter_by(username=username).first()
        
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            flash('Login berhasil!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Username atau password salah!', 'danger')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Anda telah logout!', 'info')
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    # Hitung statistik
    total_nikah = DataPernikahan.query.count()
    total_bulan_ini = DataPernikahan.query.filter_by(
        bulan=datetime.now().month, 
        tahun=datetime.now().year
    ).count()
    
    # Ambil data KUA
    data_kua = DataKUA.query.first()
    if not data_kua:
        data_kua = DataKUA(
            nama_kua='KUA ANAK RATU AJI',
            nama_kepala_kua='KOSIM, S.Ag,M.H',
            nip_kepala_kua='197709132005011005',
            email='kua.anakratuaji@gmail.com',
            no_hp='081234567890',
            alamat='Jalan Ponpes Walisongo Maruyung, Bandar Putih Tua',
            kode_pos='35513'
        )
        db.session.add(data_kua)
        db.session.commit()
    
    return render_template('dashboard.html', 
                         total_nikah=total_nikah,
                         total_bulan_ini=total_bulan_ini,
                         data_kua=data_kua)

# ==================== ADMIN ROUTES ====================

@app.route('/admin/data-kua', methods=['GET', 'POST'])
@login_required
def admin_data_kua():
    data_kua = DataKUA.query.first()
    
    if request.method == 'POST':
        if not data_kua:
            data_kua = DataKUA()
        
        data_kua.nama_kua = request.form.get('nama_kua')
        data_kua.nama_kepala_kua = request.form.get('nama_kepala_kua')
        data_kua.nip_kepala_kua = request.form.get('nip_kepala_kua')
        data_kua.email = request.form.get('email')
        data_kua.no_hp = request.form.get('no_hp')
        data_kua.alamat = request.form.get('alamat')
        data_kua.kode_pos = request.form.get('kode_pos')
        data_kua.provinsi = request.form.get('provinsi')
        data_kua.kabupaten = request.form.get('kabupaten')
        data_kua.kecamatan = request.form.get('kecamatan')
        data_kua.kode_kua = request.form.get('kode_kua')
        
        db.session.add(data_kua)
        db.session.commit()
        flash('Data KUA berhasil disimpan!', 'success')
        return redirect(url_for('admin_data_kua'))
    
    return render_template('admin_data_kua.html', data_kua=data_kua)

@app.route('/admin/desa', methods=['GET', 'POST'])
@login_required
def admin_desa():
    if request.method == 'POST':
        nama_desa = request.form.get('nama_desa')
        if nama_desa:
            desa = Desa(nama_desa=nama_desa)
            db.session.add(desa)
            db.session.commit()
            flash('Desa berhasil ditambahkan!', 'success')
        return redirect(url_for('admin_desa'))
    
    desa_list = Desa.query.order_by(Desa.nama_desa).all()
    return render_template('admin_desa.html', desa_list=desa_list)

@app.route('/admin/desa/hapus/<int:id>')
@login_required
def hapus_desa(id):
    desa = Desa.query.get_or_404(id)
    db.session.delete(desa)
    db.session.commit()
    flash('Desa berhasil dihapus!', 'success')
    return redirect(url_for('admin_desa'))

@app.route('/admin/no-porporasi', methods=['GET', 'POST'])
@login_required
def admin_no_porporasi():
    if request.method == 'POST':
        bulan = int(request.form.get('bulan'))
        tahun = int(request.form.get('tahun'))
        no_awal = request.form.get('no_awal')
        no_akhir = request.form.get('no_akhir')
        jumlah = int(request.form.get('jumlah'))
        
        # Cek apakah sudah ada data untuk bulan dan tahun tersebut
        porporasi = NoPorporasi.query.filter_by(bulan=bulan, tahun=tahun).first()
        if not porporasi:
            porporasi = NoPorporasi(bulan=bulan, tahun=tahun)
        
        porporasi.no_awal = no_awal
        porporasi.no_akhir = no_akhir
        porporasi.jumlah = jumlah
        
        db.session.add(porporasi)
        db.session.commit()
        flash('Data No Porporasi berhasil disimpan!', 'success')
        return redirect(url_for('admin_no_porporasi'))
    
    porporasi_list = NoPorporasi.query.order_by(NoPorporasi.tahun.desc(), NoPorporasi.bulan.desc()).all()
    return render_template('admin_no_porporasi.html', porporasi_list=porporasi_list)

@app.route('/admin/no-porporasi/hapus/<int:id>')
@login_required
def hapus_no_porporasi(id):
    porporasi = NoPorporasi.query.get_or_404(id)
    db.session.delete(porporasi)
    db.session.commit()
    flash('Data No Porporasi berhasil dihapus!', 'success')
    return redirect(url_for('admin_no_porporasi'))

# ==================== DATA MASTER ROUTES ====================

@app.route('/data-master')
@login_required
def data_master():
    page = request.args.get('page', 1, type=int)
    per_page = 20
    
    # Filter
    bulan = request.args.get('bulan', type=int)
    tahun = request.args.get('tahun', type=int)
    
    query = DataPernikahan.query
    if bulan:
        query = query.filter_by(bulan=bulan)
    if tahun:
        query = query.filter_by(tahun=tahun)
    
    data = query.order_by(DataPernikahan.id.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    return render_template('data_master.html', data=data, bulan=bulan, tahun=tahun)

@app.route('/data-master/upload', methods=['POST'])
@login_required
def upload_data_master():
    if 'file' not in request.files:
        flash('Tidak ada file yang dipilih!', 'danger')
        return redirect(url_for('data_master'))
    
    file = request.files['file']
    if file.filename == '':
        flash('Tidak ada file yang dipilih!', 'danger')
        return redirect(url_for('data_master'))
    
    if file and (file.filename.endswith('.xls') or file.filename.endswith('.xlsx')):
        try:
            # Baca file Excel
            df = pd.read_excel(file)
            
            # Proses data
            bulan = request.form.get('bulan', datetime.now().month, type=int)
            tahun = request.form.get('tahun', datetime.now().year, type=int)
            
            count = 0
            for _, row in df.iterrows():
                try:
                    # Buat objek DataPernikahan
                    pernikahan = DataPernikahan()
                    
                    # Mapping kolom dari Excel ke database
                    pernikahan.no_urut = safe_int(row.get('No'))
                    pernikahan.no_seri_huruf = safe_str(row.get('No Seri Huruf'))
                    pernikahan.no_perforasi = safe_str(row.get('No Perforasi'))
                    pernikahan.no_pemeriksaan = safe_str(row.get('No Pemeriksaan'))
                    pernikahan.no_aktanikah = safe_str(row.get('No Aktanikah'))
                    pernikahan.no_pendaftaran = safe_str(row.get('No Pendaftaran'))
                    pernikahan.tanggal_daftar = safe_date(row.get('Tanggal Daftar'))
                    pernikahan.tanggal_akad = safe_date(row.get('Tanggal Akad'))
                    pernikahan.jam_akad = safe_str(row.get('Jam Akad'))
                    pernikahan.alamat_akad = safe_str(row.get('Alamat Akad Nikah'))
                    pernikahan.nama_kelurahan = safe_str(row.get('Nama Kelurahan'))
                    
                    # Data Suami
                    pernikahan.nik_suami = safe_str(row.get('NIK Suami'))
                    pernikahan.nama_suami = safe_str(row.get('Nama Suami'))
                    pernikahan.tempat_lahir_suami = safe_str(row.get('Tempat Lahir Suami'))
                    pernikahan.tanggal_lahir_suami = safe_date(row.get('Tanggal Lahir Suami'))
                    pernikahan.umur_suami = safe_int(row.get('Umur Suami'))
                    pernikahan.warganegara_suami = safe_str(row.get('Warganegara Suami'))
                    pernikahan.pendidikan_suami = safe_str(row.get('Pendidikan Suami'))
                    pernikahan.pekerjaan_suami = safe_str(row.get('Pekerjaan Suami'))
                    pernikahan.alamat_suami = safe_str(row.get('Alamat Suami'))
                    pernikahan.status_suami = safe_str(row.get('Status Suami'))
                    pernikahan.nama_ayah_suami = safe_str(row.get('Nama Ayah Suami'))
                    pernikahan.nama_ibu_suami = safe_str(row.get('Nama Ibu Suami'))
                    
                    # Data Istri
                    pernikahan.nik_istri = safe_str(row.get('NIK Istri'))
                    pernikahan.nama_istri = safe_str(row.get('Nama Istri'))
                    pernikahan.tempat_lahir_istri = safe_str(row.get('Tempat Lahir Istri'))
                    pernikahan.tanggal_lahir_istri = safe_date(row.get('Tanggal Lahir Istri'))
                    pernikahan.umur_istri = safe_int(row.get('Umur Istri'))
                    pernikahan.warganegara_istri = safe_str(row.get('Warganegara Istri'))
                    pernikahan.pendidikan_istri = safe_str(row.get('Pendidikan Istri'))
                    pernikahan.pekerjaan_istri = safe_str(row.get('Pekerjaan Istri'))
                    pernikahan.alamat_istri = safe_str(row.get('Alamat Istri'))
                    pernikahan.status_istri = safe_str(row.get('Status Istri'))
                    pernikahan.nama_ayah_istri = safe_str(row.get('Nama Ayah Istri'))
                    pernikahan.nama_ibu_istri = safe_str(row.get('Nama Ibu Istri'))
                    
                    # Data Wali
                    pernikahan.status_wali = safe_str(row.get('Status Wali'))
                    pernikahan.hubungan_wali = safe_str(row.get('Hubungan Wali'))
                    pernikahan.sebab_wali = safe_str(row.get('Sebab Menjadi Wali'))
                    pernikahan.nik_wali = safe_str(row.get('NIK Wali'))
                    pernikahan.nama_wali = safe_str(row.get('Nama Lengkap Wali'))
                    pernikahan.tempat_lahir_wali = safe_str(row.get('Tempat Lahir Wali'))
                    pernikahan.tanggal_lahir_wali = safe_date(row.get('Tanggal Lahir Wali'))
                    pernikahan.alamat_wali = safe_str(row.get('Alamat Tinggal Wali'))
                    
                    # Data Penghulu
                    pernikahan.nip_penghulu = safe_str(row.get('NIP/NIK Penghulu Pemeriksa'))
                    pernikahan.nama_penghulu = safe_str(row.get('Nama Penghulu Pemeriksa'))
                    
                    # Data Saksi
                    pernikahan.nik_saksi1 = safe_str(row.get('NIK Saksi Satu'))
                    pernikahan.nama_saksi1 = safe_str(row.get('Nama Saksi Satu'))
                    pernikahan.nik_saksi2 = safe_str(row.get('NIK Saksi Dua'))
                    pernikahan.nama_saksi2 = safe_str(row.get('Nama Saksi Dua'))
                    
                    # Data Pembayaran
                    pernikahan.mas_kawin = safe_str(row.get('Mas Kawin'))
                    pernikahan.no_ntpn = safe_str(row.get('No NTPN'))
                    pernikahan.tanggal_bayar = safe_datetime(row.get('Tanggal Bayar'))
                    
                    # Kategori
                    nikah_di = safe_str(row.get('Nikah Di'))
                    pernikahan.nikah_di = nikah_di
                    pernikahan.isbat_nikah = 'isbat' in nikah_di.lower() if nikah_di else False
                    pernikahan.rujuk = 'rujuk' in nikah_di.lower() if nikah_di else False
                    
                    # Metadata
                    pernikahan.bulan = bulan
                    pernikahan.tahun = tahun
                    
                    db.session.add(pernikahan)
                    count += 1
                    
                except Exception as e:
                    print(f"Error processing row: {e}")
                    continue
            
            db.session.commit()
            flash(f'Berhasil mengupload {count} data pernikahan!', 'success')
            
        except Exception as e:
            flash(f'Error membaca file: {str(e)}', 'danger')
    else:
        flash('Format file tidak valid. Harus .xls atau .xlsx', 'danger')
    
    return redirect(url_for('data_master'))

@app.route('/data-master/hapus/<int:id>')
@login_required
def hapus_data_pernikahan(id):
    data = DataPernikahan.query.get_or_404(id)
    db.session.delete(data)
    db.session.commit()
    flash('Data pernikahan berhasil dihapus!', 'success')
    return redirect(url_for('data_master'))

# ==================== LAPORAN ROUTES ====================

@app.route('/laporan')
@login_required
def laporan():
    return render_template('laporan.html')

@app.route('/laporan/nr')
@login_required
def laporan_nr():
    bulan = request.args.get('bulan', datetime.now().month, type=int)
    tahun = request.args.get('tahun', datetime.now().year, type=int)
    
    # Ambil data pernikahan untuk bulan dan tahun tersebut
    data = DataPernikahan.query.filter_by(bulan=bulan, tahun=tahun).all()
    
    # Hitung statistik
    jumlah_nikah = len(data)
    jumlah_isbat = sum(1 for d in data if d.isbat_nikah)
    jumlah_rujuk = sum(1 for d in data if d.rujuk)
    
    # Tempat nikah
    nikah_di_kua = sum(1 for d in data if d.nikah_di and 'KUA' in d.nikah_di.upper())
    nikah_luar_kua = sum(1 for d in data if d.nikah_di and 'LUAR' in d.nikah_di.upper())
    
    # Wali nikah
    wali_nasab = sum(1 for d in data if d.status_wali and 'NASAB' in d.status_wali.upper())
    wali_hakim = sum(1 for d in data if d.status_wali and 'HAKIM' in d.status_wali.upper())
    
    # Usia suami
    suami_under_19 = sum(1 for d in data if d.umur_suami and d.umur_suami < 19)
    suami_19_21 = sum(1 for d in data if d.umur_suami and 19 <= d.umur_suami <= 21)
    suami_above_21 = sum(1 for d in data if d.umur_suami and d.umur_suami > 21)
    
    # Usia istri
    istri_under_19 = sum(1 for d in data if d.umur_istri and d.umur_istri < 19)
    istri_19_21 = sum(1 for d in data if d.umur_istri and 19 <= d.umur_istri <= 21)
    istri_above_21 = sum(1 for d in data if d.umur_istri and d.umur_istri > 21)
    
    # Pendidikan suami
    suami_sd = sum(1 for d in data if d.pendidikan_suami and 'SD' in d.pendidikan_suami.upper())
    suami_smp = sum(1 for d in data if d.pendidikan_suami and ('SMP' in d.pendidikan_suami.upper() or 'SLTP' in d.pendidikan_suami.upper()))
    suami_sma = sum(1 for d in data if d.pendidikan_suami and ('SMA' in d.pendidikan_suami.upper() or 'SLTA' in d.pendidikan_suami.upper()))
    suami_s1 = sum(1 for d in data if d.pendidikan_suami and 'S1' in d.pendidikan_suami.upper())
    suami_s2_s3 = sum(1 for d in data if d.pendidikan_suami and ('S2' in d.pendidikan_suami.upper() or 'S3' in d.pendidikan_suami.upper()))
    
    # Pendidikan istri
    istri_sd = sum(1 for d in data if d.pendidikan_istri and 'SD' in d.pendidikan_istri.upper())
    istri_smp = sum(1 for d in data if d.pendidikan_istri and ('SMP' in d.pendidikan_istri.upper() or 'SLTP' in d.pendidikan_istri.upper()))
    istri_sma = sum(1 for d in data if d.pendidikan_istri and ('SMA' in d.pendidikan_istri.upper() or 'SLTA' in d.pendidikan_istri.upper()))
    istri_s1 = sum(1 for d in data if d.pendidikan_istri and 'S1' in d.pendidikan_istri.upper())
    istri_s2_s3 = sum(1 for d in data if d.pendidikan_istri and ('S2' in d.pendidikan_istri.upper() or 'S3' in d.pendidikan_istri.upper()))
    
    # Hitung penerimaan PNBP (Rp 600.000 per nikah di luar KUA)
    penerimaan_pnbp = nikah_luar_kua * 600000
    
    # Data KUA
    data_kua = DataKUA.query.first()
    
    # Data stok buku nikah
    stok = StokBukuNikah.query.filter_by(bulan=bulan, tahun=tahun).first()
    
    # Data porporasi
    porporasi = NoPorporasi.query.filter_by(bulan=bulan, tahun=tahun).first()
    
    return render_template('laporan_nr.html',
                         bulan=bulan,
                         tahun=tahun,
                         data_kua=data_kua,
                         jumlah_nikah=jumlah_nikah,
                         jumlah_isbat=jumlah_isbat,
                         jumlah_rujuk=jumlah_rujuk,
                         nikah_di_kua=nikah_di_kua,
                         nikah_luar_kua=nikah_luar_kua,
                         wali_nasab=wali_nasab,
                         wali_hakim=wali_hakim,
                         suami_under_19=suami_under_19,
                         suami_19_21=suami_19_21,
                         suami_above_21=suami_above_21,
                         istri_under_19=istri_under_19,
                         istri_19_21=istri_19_21,
                         istri_above_21=istri_above_21,
                         suami_sd=suami_sd,
                         suami_smp=suami_smp,
                         suami_sma=suami_sma,
                         suami_s1=suami_s1,
                         suami_s2_s3=suami_s2_s3,
                         istri_sd=istri_sd,
                         istri_smp=istri_smp,
                         istri_sma=istri_sma,
                         istri_s1=istri_s1,
                         istri_s2_s3=istri_s2_s3,
                         penerimaan_pnbp=penerimaan_pnbp,
                         stok=stok,
                         porporasi=porporasi)

@app.route('/laporan/perkawinan-islam')
@login_required
def laporan_perkawinan_islam():
    bulan = request.args.get('bulan', datetime.now().month, type=int)
    tahun = request.args.get('tahun', datetime.now().year, type=int)
    
    # Ambil data pernikahan untuk bulan dan tahun tersebut
    data = DataPernikahan.query.filter_by(bulan=bulan, tahun=tahun).order_by(DataPernikahan.id).all()
    
    # Data KUA
    data_kua = DataKUA.query.first()
    
    return render_template('laporan_perkawinan_islam.html',
                         bulan=bulan,
                         tahun=tahun,
                         data_kua=data_kua,
                         data=data)

@app.route('/laporan/pnbp')
@login_required
def laporan_pnbp():
    bulan = request.args.get('bulan', datetime.now().month, type=int)
    tahun = request.args.get('tahun', datetime.now().year, type=int)
    
    # Ambil data pernikahan untuk bulan dan tahun tersebut
    data = DataPernikahan.query.filter_by(bulan=bulan, tahun=tahun).all()
    
    # Hitung penerimaan
    nikah_luar_kua = sum(1 for d in data if d.nikah_di and 'LUAR' in d.nikah_di.upper())
    penerimaan_nikah = nikah_luar_kua * 600000
    
    # Data KUA
    data_kua = DataKUA.query.first()
    
    return render_template('laporan_pnbp.html',
                         bulan=bulan,
                         tahun=tahun,
                         data_kua=data_kua,
                         nikah_luar_kua=nikah_luar_kua,
                         penerimaan_nikah=penerimaan_nikah)

# ==================== EXPORT ROUTES ====================

@app.route('/export/nr/pdf')
@login_required
def export_nr_pdf():
    bulan = request.args.get('bulan', datetime.now().month, type=int)
    tahun = request.args.get('tahun', datetime.now().year, type=int)
    
    # Generate PDF
    buffer = generate_laporan_nr_pdf(bulan, tahun)
    
    filename = f"LAPORAN_NR_{get_bulan_nama(bulan)}_{tahun}.pdf"
    return send_file(buffer, as_attachment=True, download_name=filename, mimetype='application/pdf')

@app.route('/export/nr/excel')
@login_required
def export_nr_excel():
    bulan = request.args.get('bulan', datetime.now().month, type=int)
    tahun = request.args.get('tahun', datetime.now().year, type=int)
    
    # Generate Excel
    buffer = generate_laporan_nr_excel(bulan, tahun)
    
    filename = f"LAPORAN_NR_{get_bulan_nama(bulan)}_{tahun}.xlsx"
    return send_file(buffer, as_attachment=True, download_name=filename, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

@app.route('/export/perkawinan/pdf')
@login_required
def export_perkawinan_pdf():
    bulan = request.args.get('bulan', datetime.now().month, type=int)
    tahun = request.args.get('tahun', datetime.now().year, type=int)
    
    # Generate PDF
    buffer = generate_laporan_perkawinan_pdf(bulan, tahun)
    
    filename = f"PELAPORAN_PERKAWINAN_ISLAM_{get_bulan_nama(bulan)}_{tahun}.pdf"
    return send_file(buffer, as_attachment=True, download_name=filename, mimetype='application/pdf')

@app.route('/export/perkawinan/excel')
@login_required
def export_perkawinan_excel():
    bulan = request.args.get('bulan', datetime.now().month, type=int)
    tahun = request.args.get('tahun', datetime.now().year, type=int)
    
    # Generate Excel
    buffer = generate_laporan_perkawinan_excel(bulan, tahun)
    
    filename = f"PELAPORAN_PERKAWINAN_ISLAM_{get_bulan_nama(bulan)}_{tahun}.xlsx"
    return send_file(buffer, as_attachment=True, download_name=filename, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

@app.route('/export/pnbp/pdf')
@login_required
def export_pnbp_pdf():
    bulan = request.args.get('bulan', datetime.now().month, type=int)
    tahun = request.args.get('tahun', datetime.now().year, type=int)
    
    # Generate PDF
    buffer = generate_laporan_pnbp_pdf(bulan, tahun)
    
    filename = f"LAPORAN_PNBP_{get_bulan_nama(bulan)}_{tahun}.pdf"
    return send_file(buffer, as_attachment=True, download_name=filename, mimetype='application/pdf')

# ==================== HELPER FUNCTIONS ====================

def safe_str(value):
    if pd.isna(value) or value is None:
        return None
    return str(value).strip()

def safe_int(value):
    if pd.isna(value) or value is None:
        return None
    try:
        return int(float(value))
    except:
        return None

def safe_date(value):
    if pd.isna(value) or value is None:
        return None
    try:
        if isinstance(value, str):
            # Coba beberapa format tanggal
            for fmt in ['%d-%m-%Y', '%Y-%m-%d', '%d/%m/%Y', '%m/%d/%Y']:
                try:
                    return datetime.strptime(value, fmt).date()
                except:
                    continue
        elif isinstance(value, datetime):
            return value.date()
        return None
    except:
        return None

def safe_datetime(value):
    if pd.isna(value) or value is None:
        return None
    try:
        if isinstance(value, str):
            return datetime.strptime(value, '%Y-%m-%d %H:%M:%S')
        elif isinstance(value, datetime):
            return value
        return None
    except:
        return None

def get_bulan_nama(bulan):
    bulan_names = {
        1: 'JANUARI', 2: 'FEBRUARI', 3: 'MARET', 4: 'APRIL',
        5: 'MEI', 6: 'JUNI', 7: 'JULI', 8: 'AGUSTUS',
        9: 'SEPTEMBER', 10: 'OKTOBER', 11: 'NOVEMBER', 12: 'DESEMBER'
    }
    return bulan_names.get(bulan, 'UNKNOWN')

# ==================== PDF GENERATION FUNCTIONS ====================

def generate_laporan_nr_pdf(bulan, tahun):
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=1*cm, leftMargin=1*cm, topMargin=1*cm, bottomMargin=1*cm)
    
    elements = []
    styles = getSampleStyleSheet()
    
    # Ambil data
    data_kua = DataKUA.query.first()
    data = DataPernikahan.query.filter_by(bulan=bulan, tahun=tahun).all()
    
    # Hitung statistik
    jumlah_nikah = len(data)
    nikah_luar_kua = sum(1 for d in data if d.nikah_di and 'LUAR' in d.nikah_di.upper())
    penerimaan_pnbp = nikah_luar_kua * 600000
    
    # Header
    header_style = ParagraphStyle('Header', parent=styles['Normal'], fontSize=10, alignment=TA_CENTER, spaceAfter=6)
    elements.append(Paragraph("KEMENTERIAN AGAMA REPUBLIK INDONESIA", header_style))
    elements.append(Paragraph(f"KANTOR KEMENTERIAN AGAMA {data_kua.kabupaten.upper() if data_kua else ''}", header_style))
    elements.append(Paragraph(f"KANTOR URUSAN AGAMA KECAMATAN {data_kua.kecamatan.upper() if data_kua else ''}", header_style))
    elements.append(Spacer(1, 0.3*cm))
    
    # Judul
    title_style = ParagraphStyle('Title', parent=styles['Normal'], fontSize=12, alignment=TA_CENTER, spaceAfter=6)
    elements.append(Paragraph("DATA PERISTIWA NIKAH/RUJUK", title_style))
    elements.append(Paragraph(f"BULAN {get_bulan_nama(bulan)} TAHUN {tahun}", title_style))
    elements.append(Spacer(1, 0.5*cm))
    
    # Tabel Rekap
    table_data = [
        ['JUMLAH NIKAH', str(jumlah_nikah), 'ISBAT NIKAH', '0', 'RUJUK', '0'],
        ['', '', 'TEMPAT NIKAH', '', 'WALI NIKAH', ''],
        ['', 'KUA', 'LUAR KUA', 'NASAB', 'HAKIM', 'CAMPURAN'],
        ['', '0', str(nikah_luar_kua), str(nikah_luar_kua), '0', '0'],
    ]
    
    table = Table(table_data, colWidths=[3*cm, 2*cm, 2*cm, 2*cm, 2*cm, 2*cm])
    table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('SPAN', (0, 0), (0, 3)),
        ('SPAN', (1, 0), (1, 3)),
        ('SPAN', (2, 0), (2, 0)),
        ('SPAN', (3, 0), (3, 0)),
        ('SPAN', (4, 0), (4, 0)),
        ('SPAN', (5, 0), (5, 0)),
    ]))
    elements.append(table)
    elements.append(Spacer(1, 0.5*cm))
    
    # Rincian
    elements.append(Paragraph("REKAP PERISTIWA NIKAH", styles['Heading3']))
    elements.append(Paragraph(f"1. Jumlah Peristiwa Nikah: {jumlah_nikah}", styles['Normal']))
    elements.append(Paragraph(f"   a. Di luar KUA/berbayar: {nikah_luar_kua}", styles['Normal']))
    elements.append(Paragraph(f"   b. Di KUA/Gratis: 0", styles['Normal']))
    elements.append(Paragraph(f"2. Jumlah Penerimaan PNBP: Rp {penerimaan_pnbp:,}", styles['Normal']))
    elements.append(Spacer(1, 0.5*cm))
    
    # Tanda tangan
    elements.append(Spacer(1, 1*cm))
    sign_style = ParagraphStyle('Sign', parent=styles['Normal'], fontSize=10, alignment=TA_RIGHT)
    elements.append(Paragraph(f"{data_kua.kecamatan if data_kua else 'Anak Ratu Aji'}, {datetime.now().day} {get_bulan_nama(datetime.now().month)} {datetime.now().year}", sign_style))
    elements.append(Paragraph("Kepala,", sign_style))
    elements.append(Spacer(1, 1.5*cm))
    elements.append(Paragraph(f"<b>{data_kua.nama_kepala_kua if data_kua else ''}</b>", sign_style))
    elements.append(Paragraph(f"NIP {data_kua.nip_kepala_kua if data_kua else ''}", sign_style))
    
    doc.build(elements)
    buffer.seek(0)
    return buffer

def generate_laporan_nr_excel(bulan, tahun):
    buffer = BytesIO()
    
    # Buat workbook
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Laporan NR"
    
    # Ambil data
    data_kua = DataKUA.query.first()
    data = DataPernikahan.query.filter_by(bulan=bulan, tahun=tahun).all()
    
    # Hitung statistik
    jumlah_nikah = len(data)
    nikah_luar_kua = sum(1 for d in data if d.nikah_di and 'LUAR' in d.nikah_di.upper())
    penerimaan_pnbp = nikah_luar_kua * 600000
    
    # Header
    ws.merge_cells('A1:H1')
    ws['A1'] = 'KEMENTERIAN AGAMA REPUBLIK INDONESIA'
    ws['A1'].alignment = Alignment(horizontal='center')
    
    ws.merge_cells('A2:H2')
    ws['A2'] = f'KANTOR KEMENTERIAN AGAMA {data_kua.kabupaten if data_kua else ""}'
    ws['A2'].alignment = Alignment(horizontal='center')
    
    ws.merge_cells('A3:H3')
    ws['A3'] = f'KANTOR URUSAN AGAMA KECAMATAN {data_kua.kecamatan if data_kua else ""}'
    ws['A3'].alignment = Alignment(horizontal='center')
    
    ws.merge_cells('A5:H5')
    ws['A5'] = 'DATA PERISTIWA NIKAH/RUJUK'
    ws['A5'].alignment = Alignment(horizontal='center')
    
    ws.merge_cells('A6:H6')
    ws['A6'] = f'BULAN {get_bulan_nama(bulan)} TAHUN {tahun}'
    ws['A6'].alignment = Alignment(horizontal='center')
    
    # Data
    ws['A8'] = 'JUMLAH NIKAH'
    ws['B8'] = jumlah_nikah
    ws['C8'] = 'ISBAT NIKAH'
    ws['D8'] = 0
    ws['E8'] = 'RUJUK'
    ws['F8'] = 0
    
    ws['A10'] = 'REKAP PERISTIWA NIKAH'
    ws['A11'] = '1. Jumlah Peristiwa Nikah:'
    ws['B11'] = jumlah_nikah
    ws['A12'] = '   a. Di luar KUA/berbayar:'
    ws['B12'] = nikah_luar_kua
    ws['A13'] = '   b. Di KUA/Gratis:'
    ws['B13'] = 0
    ws['A14'] = '2. Jumlah Penerimaan PNBP:'
    ws['B14'] = penerimaan_pnbp
    
    # Tanda tangan
    row = 20
    ws[f'G{row}'] = f'{data_kua.kecamatan if data_kua else ""}, {datetime.now().day} {get_bulan_nama(datetime.now().month)} {datetime.now().year}'
    ws[f'G{row+1}'] = 'Kepala,'
    ws[f'G{row+4}'] = data_kua.nama_kepala_kua if data_kua else ''
    ws[f'G{row+5}'] = f'NIP {data_kua.nip_kepala_kua if data_kua else ""}'
    
    wb.save(buffer)
    buffer.seek(0)
    return buffer

def generate_laporan_perkawinan_pdf(bulan, tahun):
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=1*cm, leftMargin=1*cm, topMargin=1*cm, bottomMargin=1*cm)
    
    elements = []
    styles = getSampleStyleSheet()
    
    # Ambil data
    data_kua = DataKUA.query.first()
    data = DataPernikahan.query.filter_by(bulan=bulan, tahun=tahun).order_by(DataPernikahan.id).all()
    
    # Header
    header_style = ParagraphStyle('Header', parent=styles['Normal'], fontSize=10, alignment=TA_CENTER, spaceAfter=6)
    elements.append(Paragraph("KEMENTERIAN AGAMA REPUBLIK INDONESIA", header_style))
    elements.append(Paragraph(f"KANTOR KEMENTERIAN AGAMA {data_kua.kabupaten.upper() if data_kua else ''}", header_style))
    elements.append(Paragraph(f"KANTOR URUSAN AGAMA KECAMATAN {data_kua.kecamatan.upper() if data_kua else ''}", header_style))
    elements.append(Paragraph(f"{data_kua.alamat if data_kua else ''} Kode Pos {data_kua.kode_pos if data_kua else ''}", header_style))
    elements.append(Spacer(1, 0.3*cm))
    
    # Judul
    title_style = ParagraphStyle('Title', parent=styles['Normal'], fontSize=12, alignment=TA_CENTER, spaceAfter=6)
    elements.append(Paragraph("PELAPORAN PERKAWINAN ISLAM", title_style))
    elements.append(Paragraph(f"KUA KECAMATAN {data_kua.kecamatan.upper() if data_kua else ''}", title_style))
    elements.append(Paragraph(f"BULAN: {get_bulan_nama(bulan)} {tahun}", title_style))
    elements.append(Spacer(1, 0.5*cm))
    
    # Tabel Data
    table_data = [['NO', 'NIK SUAMI', 'NIK ISTERI', 'NAMA LENGKAP SUAMI', 'NAMA LENGKAP ISTERI', 
                   'TEMPAT LAHIR SUAMI', 'TEMPAT LAHIR ISTERI', 'TANGGAL LAHIR SUAMI', 'TANGGAL LAHIR ISTERI',
                   'TEMPAT DAN TANGGAL MENIKAH', 'NOMOR AKTA NIKAH', 'NIK PELAPOR', 'KET']]
    
    for i, d in enumerate(data, 1):
        table_data.append([
            str(i),
            d.nik_suami or '',
            d.nik_istri or '',
            d.nama_suami or '',
            d.nama_istri or '',
            d.tempat_lahir_suami or '',
            d.tempat_lahir_istri or '',
            str(d.tanggal_lahir_suami) if d.tanggal_lahir_suami else '',
            str(d.tanggal_lahir_istri) if d.tanggal_lahir_istri else '',
            f"{d.nama_kelurahan or ''} {d.tanggal_akad or ''}",
            d.no_aktanikah or '',
            d.nik_istri or '',
            ''
        ])
    
    table = Table(table_data, repeatRows=1)
    table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
        ('FONTSIZE', (0, 0), (-1, -1), 7),
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
    ]))
    elements.append(table)
    
    # Tanda tangan
    elements.append(Spacer(1, 1*cm))
    sign_style = ParagraphStyle('Sign', parent=styles['Normal'], fontSize=10, alignment=TA_RIGHT)
    elements.append(Paragraph(f"{data_kua.kecamatan if data_kua else 'Anak Ratu Aji'}, {datetime.now().day} {get_bulan_nama(datetime.now().month)} {datetime.now().year}", sign_style))
    elements.append(Paragraph("Kepala,", sign_style))
    elements.append(Spacer(1, 1.5*cm))
    elements.append(Paragraph(f"<b>{data_kua.nama_kepala_kua if data_kua else ''}</b>", sign_style))
    elements.append(Paragraph(f"NIP {data_kua.nip_kepala_kua if data_kua else ''}", sign_style))
    
    doc.build(elements)
    buffer.seek(0)
    return buffer

def generate_laporan_perkawinan_excel(bulan, tahun):
    buffer = BytesIO()
    
    # Buat workbook
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Pelaporan Perkawinan"
    
    # Ambil data
    data_kua = DataKUA.query.first()
    data = DataPernikahan.query.filter_by(bulan=bulan, tahun=tahun).order_by(DataPernikahan.id).all()
    
    # Header
    ws.merge_cells('A1:M1')
    ws['A1'] = 'KEMENTERIAN AGAMA REPUBLIK INDONESIA'
    ws['A1'].alignment = Alignment(horizontal='center')
    
    ws.merge_cells('A2:M2')
    ws['A2'] = f'KANTOR KEMENTERIAN AGAMA {data_kua.kabupaten if data_kua else ""}'
    ws['A2'].alignment = Alignment(horizontal='center')
    
    ws.merge_cells('A3:M3')
    ws['A3'] = f'KANTOR URUSAN AGAMA KECAMATAN {data_kua.kecamatan if data_kua else ""}'
    ws['A3'].alignment = Alignment(horizontal='center')
    
    ws.merge_cells('A5:M5')
    ws['A5'] = 'PELAPORAN PERKAWINAN ISLAM'
    ws['A5'].alignment = Alignment(horizontal='center')
    
    ws.merge_cells('A6:M6')
    ws['A6'] = f'KUA KECAMATAN {data_kua.kecamatan if data_kua else ""}'
    ws['A6'].alignment = Alignment(horizontal='center')
    
    ws.merge_cells('A7:M7')
    ws['A7'] = f'BULAN: {get_bulan_nama(bulan)} {tahun}'
    ws['A7'].alignment = Alignment(horizontal='center')
    
    # Headers
    headers = ['NO', 'NIK SUAMI', 'NIK ISTERI', 'NAMA LENGKAP SUAMI', 'NAMA LENGKAP ISTERI',
               'TEMPAT LAHIR SUAMI', 'TEMPAT LAHIR ISTERI', 'TANGGAL LAHIR SUAMI', 'TANGGAL LAHIR ISTERI',
               'TEMPAT DAN TANGGAL MENIKAH', 'NOMOR AKTA NIKAH', 'NIK PELAPOR', 'KET']
    
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=9, column=col, value=header)
        cell.font = Font(bold=True)
        cell.alignment = Alignment(horizontal='center')
    
    # Data
    for i, d in enumerate(data, 1):
        row = 9 + i
        ws.cell(row=row, column=1, value=i)
        ws.cell(row=row, column=2, value=d.nik_suami)
        ws.cell(row=row, column=3, value=d.nik_istri)
        ws.cell(row=row, column=4, value=d.nama_suami)
        ws.cell(row=row, column=5, value=d.nama_istri)
        ws.cell(row=row, column=6, value=d.tempat_lahir_suami)
        ws.cell(row=row, column=7, value=d.tempat_lahir_istri)
        ws.cell(row=row, column=8, value=str(d.tanggal_lahir_suami) if d.tanggal_lahir_suami else '')
        ws.cell(row=row, column=9, value=str(d.tanggal_lahir_istri) if d.tanggal_lahir_istri else '')
        ws.cell(row=row, column=10, value=f"{d.nama_kelurahan or ''} {str(d.tanggal_akad) if d.tanggal_akad else ''}")
        ws.cell(row=row, column=11, value=d.no_aktanikah)
        ws.cell(row=row, column=12, value=d.nik_istri)
        ws.cell(row=row, column=13, value='')
    
    wb.save(buffer)
    buffer.seek(0)
    return buffer

def generate_laporan_pnbp_pdf(bulan, tahun):
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=1*cm, leftMargin=1*cm, topMargin=1*cm, bottomMargin=1*cm)
    
    elements = []
    styles = getSampleStyleSheet()
    
    # Ambil data
    data_kua = DataKUA.query.first()
    data = DataPernikahan.query.filter_by(bulan=bulan, tahun=tahun).all()
    
    # Hitung penerimaan
    nikah_luar_kua = sum(1 for d in data if d.nikah_di and 'LUAR' in d.nikah_di.upper())
    penerimaan_nikah = nikah_luar_kua * 600000
    
    # Header
    header_style = ParagraphStyle('Header', parent=styles['Normal'], fontSize=10, alignment=TA_CENTER, spaceAfter=6)
    elements.append(Paragraph("KEMENTERIAN AGAMA REPUBLIK INDONESIA", header_style))
    elements.append(Paragraph(f"KANTOR KEMENTERIAN AGAMA {data_kua.kabupaten.upper() if data_kua else ''}", header_style))
    elements.append(Paragraph(f"KANTOR URUSAN AGAMA KECAMATAN {data_kua.kecamatan.upper() if data_kua else ''}", header_style))
    elements.append(Spacer(1, 0.3*cm))
    
    # Judul
    title_style = ParagraphStyle('Title', parent=styles['Normal'], fontSize=12, alignment=TA_CENTER, spaceAfter=6)
    elements.append(Paragraph("LAPORAN PENERIMAAN NEGARA BUKAN PAJAK (PNBP)", title_style))
    elements.append(Paragraph(f"BULAN {get_bulan_nama(bulan)} TAHUN {tahun}", title_style))
    elements.append(Spacer(1, 0.5*cm))
    
    # Tabel PNBP
    table_data = [
        ['NO', 'JENIS PENERIMAAN', 'VOLUME', 'SATUAN', 'TARIF', 'JUMLAH'],
        ['1', 'Penerimaan Nikah di Luar KUA', str(nikah_luar_kua), 'Perkawinan', '600.000', f'Rp {penerimaan_nikah:,}'],
        ['', '', '', '', '', ''],
        ['', 'TOTAL', '', '', '', f'Rp {penerimaan_nikah:,}'],
    ]
    
    table = Table(table_data, colWidths=[1*cm, 6*cm, 2*cm, 2.5*cm, 2.5*cm, 3*cm])
    table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
    ]))
    elements.append(table)
    elements.append(Spacer(1, 0.5*cm))
    
    # Tanda tangan
    elements.append(Spacer(1, 1*cm))
    sign_style = ParagraphStyle('Sign', parent=styles['Normal'], fontSize=10, alignment=TA_RIGHT)
    elements.append(Paragraph(f"{data_kua.kecamatan if data_kua else 'Anak Ratu Aji'}, {datetime.now().day} {get_bulan_nama(datetime.now().month)} {datetime.now().year}", sign_style))
    elements.append(Paragraph("Kepala,", sign_style))
    elements.append(Spacer(1, 1.5*cm))
    elements.append(Paragraph(f"<b>{data_kua.nama_kepala_kua if data_kua else ''}</b>", sign_style))
    elements.append(Paragraph(f"NIP {data_kua.nip_kepala_kua if data_kua else ''}", sign_style))
    
    doc.build(elements)
    buffer.seek(0)
    return buffer

# ==================== INITIALIZATION ====================

def init_db():
    with app.app_context():
        db.create_all()
        
        # Buat user admin default jika belum ada
        admin = User.query.filter_by(username='admin').first()
        if not admin:
            admin = User(
                username='admin',
                password_hash=generate_password_hash('admin123'),
                is_admin=True
            )
            db.session.add(admin)
            db.session.commit()
            print("User admin default dibuat: username=admin, password=admin123")
        
        # Buat data KUA default jika belum ada
        data_kua = DataKUA.query.first()
        if not data_kua:
            data_kua = DataKUA(
                nama_kua='KUA ANAK RATU AJI',
                nama_kepala_kua='KOSIM, S.Ag,M.H',
                nip_kepala_kua='197709132005011005',
                email='kua.anakratuaji@gmail.com',
                no_hp='081234567890',
                alamat='Jalan Ponpes Walisongo Maruyung, Bandar Putih Tua',
                kode_pos='35513',
                provinsi='LAMPUNG',
                kabupaten='KAB. LAMPUNG TENGAH',
                kecamatan='ANAK RATU AJI',
                kode_kua='1802271'
            )
            db.session.add(data_kua)
            db.session.commit()
            print("Data KUA default dibuat")

# ==================== MAIN ====================

if __name__ == '__main__':
    init_db()
    app.run(debug=True, host='0.0.0.0', port=5000)
