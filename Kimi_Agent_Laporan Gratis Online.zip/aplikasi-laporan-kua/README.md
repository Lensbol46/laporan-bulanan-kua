# Aplikasi Laporan Bulanan KUA

Aplikasi web gratis dan open source untuk membuat laporan bulanan KUA (Kantor Urusan Agama). Aplikasi ini dirancang untuk memudahkan pembuatan laporan:
- Laporan NR (Nikah/Rujuk)
- Laporan Perkawinan Islam
- Laporan PNBP (Penerimaan Negara Bukan Pajak)

## Fitur Utama

### 1. Panel Admin
- **Data KUA**: Mengelola informasi KUA (nama, kepala KUA, alamat, kontak)
- **Data Desa**: Mengelola daftar desa/kelurahan
- **No. Porporasi**: Mengelola nomor seri buku nikah

### 2. Data Master
- Upload data pernikahan dari file Excel (format download Kemenag)
- Filter data per bulan dan tahun
- Hapus data pernikahan

### 3. Laporan Otomatis
- Generate laporan NR dengan statistik lengkap
- Generate laporan Perkawinan Islam
- Generate laporan PNBP (perhitungan otomatis Rp 600.000/nikah di luar KUA)
- Export ke format PDF dan Excel
- Print langsung dari browser

## Cara Install di Local

### 1. Clone Repository
```bash
cd aplikasi-laporan-kua
```

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Jalankan Aplikasi
```bash
python app.py
```

Aplikasi akan berjalan di `http://localhost:5000`

### 4. Login Default
- **Username**: `admin`
- **Password**: `admin123`

## Cara Deploy ke Render (Gratis)

### 1. Buat Akun Render
- Kunjungi https://render.com
- Daftar dengan akun GitHub

### 2. Create New Web Service
- Klik "New" → "Web Service"
- Connect dengan repository GitHub Anda
- Pilih repository aplikasi-laporan-kua

### 3. Konfigurasi
- **Name**: `aplikasi-laporan-kua` (atau nama lain)
- **Runtime**: `Python 3`
- **Build Command**: `pip install -r requirements.txt`
- **Start Command**: `gunicorn app:app`
- **Plan**: Free

### 4. Deploy
- Klik "Create Web Service"
- Tunggu proses deploy selesai
- Aplikasi akan live di URL yang diberikan Render

## Cara Deploy ke Railway (Gratis)

### 1. Buat Akun Railway
- Kunjungi https://railway.app
- Daftar dengan akun GitHub

### 2. Create New Project
- Klik "New Project"
- Pilih "Deploy from GitHub repo"
- Pilih repository aplikasi-laporan-kua

### 3. Deploy
- Railway akan otomatis mendeteksi Python dan deploy
- Aplikasi akan live di URL yang diberikan Railway

## Cara Deploy ke Heroku (Gratis Tier)

### 1. Install Heroku CLI
```bash
# Download dari https://devcenter.heroku.com/articles/heroku-cli
```

### 2. Login dan Create App
```bash
heroku login
heroku create nama-aplikasi-anda
```

### 3. Deploy
```bash
git init
git add .
git commit -m "Initial commit"
git push heroku main
```

## Struktur Folder

```
aplikasi-laporan-kua/
├── app.py                 # Main application
├── requirements.txt       # Python dependencies
├── Procfile              # Heroku/Railway config
├── runtime.txt           # Python version
├── README.md             # This file
├── static/
│   ├── css/             # Stylesheets
│   ├── js/              # JavaScript files
│   └── uploads/         # Uploaded files
├── templates/            # HTML templates
│   ├── base.html
│   ├── login.html
│   ├── dashboard.html
│   ├── data_master.html
│   ├── admin_data_kua.html
│   ├── admin_desa.html
│   ├── admin_no_porporasi.html
│   ├── laporan.html
│   ├── laporan_nr.html
│   ├── laporan_perkawinan_islam.html
│   └── laporan_pnbp.html
└── instance/            # Database SQLite
```

## Penggunaan

### 1. Setup Awal
1. Login dengan akun default
2. Buka menu **Admin > Data KUA**
3. Isi semua informasi KUA Anda
4. Simpan perubahan

### 2. Upload Data Master
1. Buka menu **Data Master**
2. Klik tombol **Upload Data**
3. Pilih bulan dan tahun
4. Pilih file Excel dari sistem Kemenag
5. Klik Upload

### 3. Generate Laporan
1. Buka menu **Laporan**
2. Pilih jenis laporan yang diinginkan
3. Pilih bulan dan tahun
4. Export ke PDF/Excel atau Print

## Format File Excel Data Master

File Excel yang diupload harus memiliki kolom-kolom berikut:
- No
- No Seri Huruf
- No Perforasi
- No Pemeriksaan
- No Aktanikah
- NIK Suami, Nama Suami, Tempat Lahir Suami, dll
- NIK Istri, Nama Istri, Tempat Lahir Istri, dll
- Tanggal Akad, Jam Akad, Alamat Akad Nikah
- Status Wali, Nama Wali, dll
- Mas Kawin, No NTPN
- Nikah Di (LUAR KUA / BEDOL atau DI KUA)

## Keamanan

- Ganti password default setelah pertama kali login
- Jangan bagikan akun admin ke orang lain
- Backup database secara berkala

## Backup Database

Database SQLite tersimpan di folder `instance/kua_database.db`. Backup dengan cara:
1. Download file `kua_database.db`
2. Simpan di tempat yang aman

## Troubleshooting

### Error: "No module named 'flask'"
```bash
pip install -r requirements.txt
```

### Error: "Permission denied"
```bash
chmod 755 app.py
```

### Database tidak terbuat
```bash
python -c "from app import init_db; init_db()"
```

## Lisensi

Aplikasi ini gratis dan open source. Silakan gunakan, modifikasi, dan distribusikan sesuai kebutuhan.

## Dukungan

Jika ada pertanyaan atau masalah, silakan buat issue di repository GitHub.

## Catatan Penting

- Aplikasi ini menggunakan SQLite untuk database (file-based)
- Data tersimpan di server/cloud sesuai tempat deploy
- Untuk production, disarankan menggunakan PostgreSQL (bisa gratis di Render/Railway)
- Backup database secara berkala untuk keamanan data

---

**Dibuat dengan ❤️ untuk KUA Indonesia**

Gratis & Open Source - Dapat digunakan selamanya
