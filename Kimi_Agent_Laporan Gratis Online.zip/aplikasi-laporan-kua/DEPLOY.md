# Panduan Deploy Aplikasi Laporan KUA

Panduan lengkap untuk deploy aplikasi ke platform gratis.

## Pilihan Platform Gratis

1. **Render** (Recommended) - https://render.com
2. **Railway** - https://railway.app
3. **PythonAnywhere** - https://pythonanywhere.com

---

## Deploy ke Render (Paling Mudah & Recommended)

### Langkah 1: Daftar Akun
1. Kunjungi https://render.com
2. Klik "Get Started for Free"
3. Daftar dengan akun GitHub, GitLab, atau Google

### Langkah 2: Upload ke GitHub
1. Buat repository baru di GitHub
2. Upload semua file aplikasi ke repository
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/username/nama-repo.git
git push -u origin main
```

### Langkah 3: Create Web Service
1. Login ke Render dashboard
2. Klik "New" → "Web Service"
3. Connect dengan repository GitHub Anda
4. Pilih repository aplikasi-laporan-kua

### Langkah 4: Konfigurasi
Isi form dengan data berikut:
- **Name**: `aplikasi-laporan-kua` (atau nama lain)
- **Runtime**: `Python 3`
- **Build Command**: `pip install -r requirements.txt`
- **Start Command**: `gunicorn app:app`
- **Plan**: Free

### Langkah 5: Deploy
1. Klik "Create Web Service"
2. Tunggu proses build dan deploy (sekitar 2-5 menit)
3. Aplikasi akan live di URL: `https://nama-aplikasi-anda.onrender.com`

### Keuntungan Render:
- ✅ Gratis selamanya
- ✅ Auto-deploy saat ada push ke GitHub
- ✅ HTTPS otomatis
- ✅ Database SQLite tersimpan persisten
- ✅ Tidak ada sleep time (selalu online)

---

## Deploy ke Railway

### Langkah 1: Daftar Akun
1. Kunjungi https://railway.app
2. Daftar dengan akun GitHub

### Langkah 2: Create New Project
1. Klik "New Project"
2. Pilih "Deploy from GitHub repo"
3. Pilih repository aplikasi Anda

### Langkah 3: Deploy
Railway akan otomatis:
- Mendeteksi Python
- Install dependencies dari requirements.txt
- Deploy aplikasi

### Langkah 4: Dapatkan Domain
1. Klik project Anda
2. Klik "Settings"
3. Klik "Generate Domain"
4. Aplikasi live di URL yang diberikan

### Keuntungan Railway:
- ✅ Gratis dengan $5 credit per bulan
- ✅ Sangat mudah setup
- ✅ Auto-deploy dari GitHub

---

## Deploy ke PythonAnywhere

### Langkah 1: Daftar Akun
1. Kunjungi https://pythonanywhere.com
2. Daftar akun gratis

### Langkah 2: Upload File
1. Login ke PythonAnywhere
2. Buka menu "Files"
3. Upload semua file aplikasi

### Langkah 3: Create Web App
1. Buka menu "Web"
2. Klik "Add a new web app"
3. Pilih "Flask"
4. Pilih Python 3.9 atau lebih baru
5. Pilih path ke file app.py

### Langkah 4: Install Dependencies
1. Buka menu "Consoles" → "Bash"
2. Jalankan:
```bash
pip install --user -r requirements.txt
```

### Langkah 5: Reload Web App
1. Kembali ke menu "Web"
2. Klik "Reload" pada aplikasi Anda

---

## Deploy ke VPS (DigitalOcean, Vultr, Linode)

Jika Anda memiliki VPS, berikut cara deploy:

### Langkah 1: Install Dependencies
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Python dan pip
sudo apt install python3 python3-pip python3-venv -y

# Install Nginx
sudo apt install nginx -y
```

### Langkah 2: Clone Repository
```bash
cd /var/www
git clone https://github.com/username/nama-repo.git
cd nama-repo
```

### Langkah 3: Setup Virtual Environment
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### Langkah 4: Setup Gunicorn
```bash
# Test gunicorn
gunicorn --bind 0.0.0.0:8000 app:app

# Create systemd service
sudo nano /etc/systemd/system/kua-app.service
```

Isi dengan:
```ini
[Unit]
Description=KUA Laporan App
After=network.target

[Service]
User=www-data
Group=www-data
WorkingDirectory=/var/www/nama-repo
Environment="PATH=/var/www/nama-repo/venv/bin"
ExecStart=/var/www/nama-repo/venv/bin/gunicorn --workers 3 --bind unix:kua-app.sock -m 007 app:app

[Install]
WantedBy=multi-user.target
```

Enable dan start service:
```bash
sudo systemctl start kua-app
sudo systemctl enable kua-app
```

### Langkah 5: Setup Nginx
```bash
sudo nano /etc/nginx/sites-available/kua-app
```

Isi dengan:
```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        include proxy_params;
        proxy_pass http://unix:/var/www/nama-repo/kua-app.sock;
    }
}
```

Enable site:
```bash
sudo ln -s /etc/nginx/sites-available/kua-app /etc/nginx/sites-enabled
sudo nginx -t
sudo systemctl restart nginx
```

---

## Backup dan Restore Database

### Backup
```bash
# Download file database
scp user@server:/path/to/instance/kua_database.db ./backup/
```

### Restore
```bash
# Upload file database
scp ./backup/kua_database.db user@server:/path/to/instance/
```

---

## Troubleshooting Deployment

### Error: "ModuleNotFoundError"
```bash
pip install -r requirements.txt
```

### Error: "Address already in use"
```bash
# Cari proses yang menggunakan port
sudo lsof -i :5000

# Kill proses
sudo kill -9 <PID>
```

### Error: "Permission denied"
```bash
sudo chmod -R 755 /var/www/nama-repo
sudo chown -R www-data:www-data /var/www/nama-repo
```

### Database tidak persisten di Render
Render gratis menyimpan data di disk yang ephemeral. Untuk data persisten:
1. Gunakan PostgreSQL gratis dari Render
2. Atau backup database secara berkala

---

## Update Aplikasi

### Update di Render/Railway
1. Push perubahan ke GitHub
2. Platform akan auto-deploy

### Update di VPS
```bash
cd /var/www/nama-repo
git pull
source venv/bin/activate
pip install -r requirements.txt
sudo systemctl restart kua-app
```

---

## Tips Keamanan

1. **Ganti SECRET_KEY**
   ```python
   # Di app.py atau config.py
   app.config['SECRET_KEY'] = 'your-secret-key-here'
   ```

2. **Ganti Password Default**
   Login pertama kali dan ganti password admin

3. **Enable HTTPS**
   - Render: Otomatis
   - Railway: Otomatis
   - VPS: Gunakan Let's Encrypt

4. **Backup Berkala**
   Backup database minimal seminggu sekali

---

## Butuh Bantuan?

Jika ada masalah dengan deployment:
1. Cek log error di dashboard platform
2. Pastikan semua dependencies terinstall
3. Cek file permissions
4. Pastikan database bisa ditulis

Selamat menggunakan aplikasi! 🎉
