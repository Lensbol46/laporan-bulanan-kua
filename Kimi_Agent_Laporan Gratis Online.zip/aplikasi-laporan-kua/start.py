#!/usr/bin/env python3
"""
Script untuk menjalankan aplikasi Laporan Bulanan KUA
"""

import os
import sys

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import app, init_db

if __name__ == '__main__':
    print("=" * 60)
    print("Aplikasi Laporan Bulanan KUA")
    print("Gratis & Open Source")
    print("=" * 60)
    print()
    
    # Initialize database
    print("Initializing database...")
    init_db()
    print("Database ready!")
    print()
    
    # Get port from environment or use default
    port = int(os.environ.get('PORT', 5000))
    
    print(f"Starting server on http://localhost:{port}")
    print()
    print("Default login:")
    print("  Username: admin")
    print("  Password: admin123")
    print()
    print("Press CTRL+C to stop")
    print("=" * 60)
    
    # Run app
    app.run(host='0.0.0.0', port=port, debug=True)
